import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import '../models/admin_transaction.dart'; // Adjust the import path based on your project structure
import '../widgets/history_card.dart';

class TransactionsScreen extends StatefulWidget {
  const TransactionsScreen({Key? key}) : super(key: key);

  @override
  _TransactionsScreenState createState() => _TransactionsScreenState();
}

class _TransactionsScreenState extends State<TransactionsScreen> {
  List<Transaction> transactions = []; // List to hold transactions
  String selectedFilter = 'All'; // State variable to hold the selected filter

  @override
  void initState() {
    super.initState();
    // Load transactions when the screen initializes
    _loadTransactions();
  }

  Future<void> _loadTransactions() async {
    try {
      var url = Uri.parse('http://127.0.0.1/localconnect/transaction_history.php'); // Replace with your actual URL
      var response = await http.get(url);

      if (response.statusCode == 200) {
        var jsonData = jsonDecode(response.body);
        if (jsonData is List) {
          List<Transaction> fetchedTransactions = jsonData
              .map((transaction) => Transaction.fromJson(transaction))
              .toList();
          fetchedTransactions.sort((a, b) => b.transDate.compareTo(a.transDate)); // Sorting transactions by transDate descending
          setState(() {
            transactions = fetchedTransactions.where((transaction) =>
              transaction.transactionStatus == 'R' ||
              transaction.transactionStatus == 'A' ||
              transaction.transactionStatus == 'N').toList();
          });
        } else {
          throw Exception('Unexpected response format');
        }
      } else {
        throw Exception('Failed to load transaction details: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Failed to fetch transaction details: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Transaction History'),
      ),
      body: Column(
        children: [
          _buildFilterButton(),
          Expanded(child: _buildTransactionList()), // Show transaction list based on fetched data
        ],
      ),
    );
  }

  Widget _buildFilterButton() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.end,
      children: [
        Padding(
          padding: const EdgeInsets.all(15),
          child: Row(
            children: [
              DropdownButton<String>(
                value: selectedFilter,
                dropdownColor: Color.fromARGB(255, 235, 238, 240),
                onChanged: (String? newValue) {
                  setState(() {
                    selectedFilter = newValue!;
                  });
                },
                items: <String>['All', 'Approved', 'Rejected', 'Returned']
                    .map<DropdownMenuItem<String>>((String value) {
                  return DropdownMenuItem<String>(
                    value: value,
                    child: Text(value),
                  );
                }).toList(),
              ),
              SizedBox(width: 15,)
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildTransactionList() {
    List<Transaction> filteredTransactions = transactions;

    if (selectedFilter != 'All') {
      filteredTransactions = transactions.where((transaction) {
        switch (selectedFilter) {
          case 'Approved':
            return transaction.transactionStatus == 'A';
          case 'Rejected':
            return transaction.transactionStatus == 'N';
          case 'Returned':
            return transaction.transactionStatus == 'R';
          default:
            return true;
        }
      }).toList();
    }

    if (filteredTransactions.isEmpty) {
      return Center(
        child: const Text(
          'No transactions found!',
          style: TextStyle(fontSize: 16),
        ),
      );
    } else {
      return ListView.builder(
        itemCount: filteredTransactions.length,
        itemBuilder: (BuildContext context, int index) {
          Transaction transaction = filteredTransactions[index];
          return TransactionsCard(
            transaction: transaction,
          );
        },
      );
    }
  }
}
